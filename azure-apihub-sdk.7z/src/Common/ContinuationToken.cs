﻿namespace Microsoft.Azure.ApiHub
{
    public class ContinuationToken
    {
        internal string NextLink { get; set; }
    }
}
