﻿using System;

namespace Microsoft.Azure.ApiHub
{
    [CLSCompliant(true)]
    public enum FileWatcherType
    {
        Created,
        Updated
    }
}
